package Day01;

public class Ex07_FloatDouble {

	public static void main(String[] args) {
		
		// 실수타입 변수 선언
		double var1 = 3.14;
		float var2 = 3.14F;
		
		// 정밀도
		double var3 = 0.1234567890123456789;
		float var4 = 0.1234567890123456789F;
		
		double PI = Math.PI;
		
		System.out.println("var1 : " + var1);
		System.out.println("var2 : " + var2);
		System.out.println("var3 : " + var3);
		System.out.println("var4 : " + var4);
		
		System.out.println("원주율 : " + PI);
		
		
	}

}
