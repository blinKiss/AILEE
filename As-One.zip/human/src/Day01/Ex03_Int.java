package Day01;

public class Ex03_Int {
	public static void main(String[] args) {
		
		// 리터럴
		// : 프로그램에서 직접 표현한 값
		
		// 10진수 = 그냥숫자 = 결과값
		int var1 = 10;
		System.out.println(var1);
		
		// 8진수 = 0숫자 = 결과값
		int var2 = 010;
		System.out.println(var2);
		
		// 16진수 = 0x숫자 = 결과값
		int var3 = 0x10;
		System.out.println(var3);
		
		
	}

	
}
