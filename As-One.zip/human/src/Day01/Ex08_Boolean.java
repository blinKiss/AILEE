package Day01;

public class Ex08_Boolean {

	public static void main(String[] args) {
		boolean on = true;
		
		System.out.println("on : " + on);

		if( on ) {
			System.out.println("전원 ON");
		} else {
			System.out.println("전원 OFF");
		}
		
		
		

	}

}
