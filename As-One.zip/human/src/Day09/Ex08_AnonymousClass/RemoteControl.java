package Day09.Ex08_AnonymousClass;

public interface RemoteControl {
	
	public void turnOn();
	
	public void turnOff();
	
}
