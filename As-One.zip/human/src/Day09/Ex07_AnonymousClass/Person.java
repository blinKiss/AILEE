package Day09.Ex07_AnonymousClass;


// 부모 클래스
public class Person {

	void work() {
		System.out.println("일을 합니다");
	}
	
}
