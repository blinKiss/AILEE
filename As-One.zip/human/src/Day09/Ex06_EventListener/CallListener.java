package Day09.Ex06_EventListener;

public class CallListener implements Button.OnClickListener {

	@Override
	public void OnClick() {
		System.out.println("전화버튼 클릭!!");
	}

	
	
	
}
