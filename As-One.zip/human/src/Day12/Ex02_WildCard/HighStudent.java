package Day12.Ex02_WildCard;

public class HighStudent extends Student {
	
	public HighStudent(String name) {
		super(name);
	}

}
