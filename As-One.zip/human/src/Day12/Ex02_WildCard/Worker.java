package Day12.Ex02_WildCard;

public class Worker extends Person {
	
	public Worker(String name) {
		super(name);
	}

	
}
