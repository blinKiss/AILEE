package noob;

public class Level3 {

	public static void main(String[] args) {
		// [][]
		//   [][]
		//     [][]
		//       [][]
		//         [][]
		int[][] a = new int[5][];
		a[0] = new int[2];
		a[1] = new int[3];
		a[2] = new int[4];
		a[3] = new int[5];
		a[4] = new int[6];

	}
}
