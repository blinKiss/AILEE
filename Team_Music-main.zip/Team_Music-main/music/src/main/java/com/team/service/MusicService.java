package com.team.service;

import java.util.List;

import com.team.domain.Music;

public interface MusicService {

	public List<Music> list() throws Exception;

}
