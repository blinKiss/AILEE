package com.team.domain;

import lombok.Data;

@Data
public class MusicUserAuth {

	private int authNo;
	private String userId;
	private String auth;
}
